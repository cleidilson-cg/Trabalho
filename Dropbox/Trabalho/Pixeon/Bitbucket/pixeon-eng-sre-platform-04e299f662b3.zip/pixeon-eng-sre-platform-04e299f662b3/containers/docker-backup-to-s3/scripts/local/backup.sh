#!/bin/bash

# Move the tarball to the destination folder
echo "Move the archive to the destination folder..."
mv $tarball ${LOCAL_TARGET}/
